package padroesempratica.entidades;

/**
 * Classe Pais.
 *
 * @author Prof. Dr. David Buzatto
 */
public class Pais {

    private int id;
    private String nome;
    private String sigla;

}
